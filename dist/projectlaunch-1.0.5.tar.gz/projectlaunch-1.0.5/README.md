# ProjectLaunch

![Python Version](https://img.shields.io/badge/python-3.8%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![PyPI](https://img.shields.io/pypi/v/projectlaunch)
![Downloads](https://img.shields.io/pypi/dm/projectlaunch)

**Simple GitHub Push Tool for Students & Developers**

Push your projects to GitHub with a single command. No complex git commands needed!

---

## What Does It Do?

ProjectLaunch simplifies pushing your code to GitHub:
- Automatically initializes git repository
- Adds all your files
- Creates a commit with your message
- Pushes to your GitHub repository
- All in one command

---

## Installation

```bash
pip install projectlaunch
```

**Requirements:**
- Python 3.8 or higher
- Git installed on your system ([Download Git](https://git-scm.com))

**IMPORTANT: After Installation**

If you see this warning during installation:
```
WARNING: The scripts pl.exe and projectlaunch.exe are installed in
'C:\Users\YourName\AppData\Roaming\Python\Python310\Scripts'
which is not on PATH.
```

**You have 2 options:**

**Option 1 (Recommended): Use `python -m projectlaunch`**

This works immediately without any configuration:
```bash
python -m projectlaunch
```

**Option 2: Fix PATH (One-time setup)**

1. Copy the path from the warning message (e.g., `C:\Users\YourName\AppData\Roaming\Python\Python310\Scripts`)
2. Press `Win + R`, type `sysdm.cpl`, press Enter
3. Go to **Advanced** tab → **Environment Variables**
4. Under **User Variables**, select **Path** → **Edit**
5. Click **New** and paste the path
6. Click **OK** everywhere
7. **Close and reopen** Command Prompt
8. Now `pl` will work

---

## Quick Start

**Two ways to use ProjectLaunch:**

1. **Short command:** `pl` (requires PATH setup)
2. **Universal command:** `python -m projectlaunch` (works everywhere)

### Basic Usage (Interactive)

Navigate to your project folder and run:

```bash
pl
# OR if 'pl' not recognized:
python -m projectlaunch
```

The tool will ask you:
1. **GitHub repository URL** - Example: `https://github.com/username/my-project`
2. **Commit message** - Example: `Initial commit` or `Added new features`

That's it! Your code is now on GitHub!

---

## Usage Examples

### Example 1: Interactive Mode (Recommended for Beginners)

```bash
cd my-project
pl
```

**Output:**
```
ProjectLaunch - GitHub Push Tool

Enter your GitHub repository URL:
Repository URL: https://github.com/username/my-project

Enter commit message:
Commit message [Initial commit]: Added homepage

Pushing to GitHub...
Initializing git...
Adding files...
Committing: Added homepage
Setting remote...
Pushing...

Successfully pushed!
Repository: https://github.com/username/my-project
```

---

### Example 2: With Command-Line Options (Faster)

```bash
pl --repo https://github.com/username/my-project --message "Initial commit"
```

**Short version:**
```bash
pl -r https://github.com/username/my-project -m "Initial commit"
```

---

### Example 3: Push from Different Directory

```bash
pl --path /path/to/your/project --repo https://github.com/username/repo
```

---

## Command Reference

### Main Command

```bash
pl [OPTIONS]
```

### Options

| Option | Short | Description | Example |
|--------|-------|-------------|---------|
| `--repo` | `-r` | GitHub repository URL | `--repo https://github.com/user/repo` |
| `--message` | `-m` | Commit message | `--message "Fixed bugs"` |
| `--path` | `-p` | Project directory path | `--path ./my-project` |
| `--help` | `-h` | Show help message | `--help` |

### Other Commands

```bash
pl --version          # Show version
pl --help            # Show all commands
projectlaunch        # Full command name (same as 'pl')
```

---

## Step-by-Step Tutorial

### First Time Setup

**Step 1: Create a GitHub Repository**

1. Go to [GitHub](https://github.com)
2. Click the **+** icon → **New repository**
3. Enter repository name (e.g., `my-awesome-project`)
4. Click **Create repository**
5. Copy the repository URL (e.g., `https://github.com/username/my-awesome-project`)

**Step 2: Install ProjectLaunch**

```bash
pip install projectlaunch
```

**Step 3: Navigate to Your Project**

```bash
cd path/to/your/project
```

**Step 4: Push to GitHub**

```bash
pl
```

Enter the repository URL you copied in Step 1, and you're done!

---

## Common Scenarios

### Scenario 1: First Time Pushing a New Project

```bash
cd my-new-project
pl
# Enter: https://github.com/username/my-new-project
# Enter: Initial commit
```

---

### Scenario 2: Updating an Existing Project

```bash
cd my-existing-project
pl -r https://github.com/username/my-existing-project -m "Updated features"
```

---

### Scenario 3: Quick Push with Default Message

```bash
pl -r https://github.com/username/repo
# Uses default message: "Update"
```

---

## FAQ

### Q: Do I need to create a GitHub repository first?
**A:** Yes! Create an empty repository on GitHub first, then use ProjectLaunch to push your code.

### Q: What if I already have a git repository?
**A:** No problem! ProjectLaunch will detect it and just push your changes.

### Q: Can I use this for private repositories?
**A:** Yes! Just make sure you're logged into GitHub on your system.

### Q: What if the push fails?
**A:** ProjectLaunch will automatically try force push. Make sure:
- Git is installed
- You have internet connection
- The repository URL is correct
- You have permission to push to the repository

### Q: Does it work on Windows/Mac/Linux?
**A:** Yes! Works on all platforms where Python and Git are installed.

---

## Troubleshooting

### Issue: 'pl' is not recognized as an internal or external command

**This is the most common issue on Windows!**

**What happened:**
After running `pip install projectlaunch`, you see:
```
WARNING: The scripts pl.exe and projectlaunch.exe are installed in
'C:\Users\YourName\AppData\Roaming\Python\Python310\Scripts'
which is not on PATH.
```

Then when you try `pl`, you get:
```
'pl' is not recognized as an internal or external command
```

**Why this happens:**
Windows doesn't know where to find the `pl.exe` file because the Scripts folder is not in your system PATH.

**SOLUTION 1 (Instant Fix - No Configuration Needed):**

Use this command instead:
```bash
python -m projectlaunch
```

This works immediately on ANY Windows system, regardless of PATH configuration!

**Examples:**
```bash
python -m projectlaunch                    # Interactive mode
python -m projectlaunch -r URL -m "msg"   # With options
python -m projectlaunch --help            # Show help
python -m projectlaunch --version         # Show version
```

**SOLUTION 2 (Permanent Fix - One-time Setup):**

Add the Scripts folder to your PATH:

1. **Find your Scripts path** from the warning message. Common locations:
   - `C:\Users\YourName\AppData\Roaming\Python\Python310\Scripts`
   - `C:\Users\YourName\AppData\Roaming\Python\Python311\Scripts`
   - `C:\Users\YourName\AppData\Roaming\Python\Python312\Scripts`

2. **Add to PATH:**
   - Press `Win + R`
   - Type `sysdm.cpl` and press Enter
   - Go to **Advanced** tab
   - Click **Environment Variables**
   - Under **User Variables**, select **Path**
   - Click **Edit**
   - Click **New**
   - Paste your Scripts path
   - Click **OK** on all windows

3. **Restart Command Prompt** (IMPORTANT!)
   - Close all Command Prompt windows
   - Open a new Command Prompt
   - Test: `pl --version`

**After PATH fix, you can use:**
```bash
pl                    # Short command
projectlaunch         # Full command
python -m projectlaunch  # Also still works
```

---

### Command not recognized: 'pl' is not recognized

**Problem:** After installing, you get:
```
'pl' is not recognized as an internal or external command
```

**Solution 1 (Recommended):** Add Python Scripts to PATH

1. Press `Win + R`, type `sysdm.cpl`, press Enter
2. Go to **Advanced** tab → **Environment Variables**
3. Under **User Variables**, select **Path** → **Edit**
4. Click **New** and add:
   ```
   %APPDATA%\Python\Python312\Scripts
   ```
   (Replace `Python312` with your Python version)
5. Click **OK** everywhere
6. **Close and reopen** Command Prompt
7. Test: `pl --version`

**Solution 2 (Quick Workaround):** Use python -m

If PATH fix doesn't work, you can always run:
```bash
python -m projectlaunch
```

This works without PATH configuration!

---

### Error: "Git not installed"

**Solution:** Install Git from [git-scm.com](https://git-scm.com)

---

### Error: "Permission denied"

**Solution:** Make sure you're logged into GitHub:
```bash
git config --global user.name "Your Name"
git config --global user.email "your@email.com"
```

---

### Error: "Repository not found"

**Solution:** 
1. Check the repository URL is correct
2. Make sure the repository exists on GitHub
3. Verify you have access to the repository

---

## Real-World Examples

### Example 1: Student Project

```bash
# You just finished your college project
cd final-year-project
pl -r https://github.com/student123/final-year-project -m "Completed project"
```

---

### Example 2: Quick Prototype

```bash
# You built a quick prototype and want to share it
cd prototype-app
pl
# Enter repo URL and message when prompted
```

---

### Example 3: Daily Updates

```bash
# End of day, pushing your work
cd work-project
pl -r https://github.com/company/work-project -m "Day 5: Implemented login feature"
```

---

## Tips & Best Practices

1. **Use descriptive commit messages**
   - Bad: `"update"`
   - Good: `"Added user authentication feature"`

2. **Push regularly**
   - Don't wait until the end of the project
   - Push after completing each feature

3. **Check your files**
   - Make sure you're not pushing sensitive data (passwords, API keys)
   - Use `.gitignore` to exclude unnecessary files

4. **Create a .gitignore file**
   ```
   # Common files to ignore
   __pycache__/
   *.pyc
   .env
   node_modules/
   .DS_Store
   ```

---

## Need Help?

- **GitHub:** [madhan112007/test-project_launch](https://github.com/madhan112007/test-project_launch)
- **Issues:** [Report bugs](https://github.com/madhan112007/test-project_launch/issues)
- **Email:** codethetrend@gmail.com
- **PyPI:** [projectlaunch](https://pypi.org/project/projectlaunch/)

---

## License

MIT License - Free to use for everyone!

---

## Credits

Built for students and developers who want a simpler way to push code to GitHub.

**Made with care by Madhan**

---

## Quick Reference Card

```bash
# Install
pip install projectlaunch

# If you see PATH warning after install, use:
python -m projectlaunch              # Works everywhere!

# OR fix PATH once, then use:
pl                                   # Short command

# Basic usage
pl                                   # Interactive mode
python -m projectlaunch              # Alternative (no PATH needed)

# With options
pl -r https://github.com/user/repo -m "Commit message"
python -m projectlaunch -r URL -m "msg"  # Alternative

# Get help
pl --help
python -m projectlaunch --help

# Check version
pl --version
python -m projectlaunch --version
```

---

**Happy Coding!**
